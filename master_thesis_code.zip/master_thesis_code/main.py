# -*- coding: utf-8 -*-
"""
Created on Sat Nov  6 11:42:20 2021

This is the main method for the Master Thesis, and contains print-outs to ease 
usage through a non-IDE console. 

@author: Jan
"""

import time #For console outputs from this file
from Folder_walk import find_examples
from Folder_walk import list_files
from matrix_comparator import matrix_comp
from file_plotter import plot_ex as plex
from Object_finder import obj_gen
# Imported for checking matrices:
from matrix_bk_check import bkcheck as bkcheck
from matrix_bk_check import mat_count as mc

work_file_list = [] # Just a failsave


def start(folder = "training/"):
    """
    Start function of the method, and the entire program. 

    Parameters
    ----------
    folder : String, optional
        The folder that the example files are to be found in. The default is "training/".

    Returns
    -------
    As this is intended to be used from a console, it just produces print-outs.

    """
    global work_file_list #Allows the file list to be used by other functions 
                          # without a return on the start function.
    work_file_list = find_examples(folder)
    if work_file_list != []:
        print("Files have been found.",
              "Available commands: filelist(), plot(), check_matrix(), compare().")
        print("For more details and advanced commands, type 'commands()'.")



def filelist(fileA = 0,fileB = 10):
    """
    Allows listing files.

    Parameters
    ----------
    fileA : Int, optional
        Index of the file the list output should start with. The default is 0.
    fileB : Int, optional
        Index of the file the list output should end with. The default is 10.

    Returns
    -------
    list_files: List
        A List of tuples of file index and file name.

    """
    return list_files(work_file_list,fileA,fileB)



def plot(File = 0, test = False, cap = 5, difmap = True ):
    """
    Generates plots, if run in an environment with provision for that, like 
    an IDE with visual output. 

    Parameters
    ----------
    File : Int, optional
        Which file's example matrices to plot. The default is 0.
    test : Bool, optional
        If, instead of training examples, the test matrix should be plotted. 
        The default is False.
    cap : Int, optional
        How many matrices should be plotted. Always starts at the first, so it is 
        not possible to just plot the last 2 examples in a matrix on their own. 
        The default is 5.
    difmap : Bool, optional
        If the difference between input and output should also be plotted. 
        The default is True.

    Returns
    -------
    Image.png
        Returns an image of file type .png. 

    """
   #Target function def: (train_in,train_out = [], is_test = False, cap = 5, detail = 3)
    show_diff = (len(work_file_list[File][1][0])*len(work_file_list[File][1][0][0]) == 
                 len(work_file_list[File][1][1])*len(work_file_list[File][1][1][0]))
                #Is showing a difference even possible? (same size arrays)
    if show_diff and difmap and not test:
        return plex(work_file_list[File][1][0],work_file_list[File][1][1])
    elif test:
        return plex(work_file_list[File][1][2],[],test, cap)
    else:
        return plex(work_file_list[File][1][0],work_file_list[File][1][1],test, cap, 2)
        
    
def compare(File = 0,Example = 0,Print = True):
    """
    Compares two matrices, producing print-outs if desired, 
    and returning a list of linked objects

    Parameters
    ----------
    File : Int, optional
        File Index from work_file_list. The default is 0.
    Example : Int, optional
        Which example to pick from the file. The default is 0.
    Print : Bool, optional
        If additional Print-Outs are desired. The default is True.

    Returns
    -------
    None.

    """
    matrix_comp(work_file_list[File][1][0][Example],
                work_file_list[File][1][1][Example],
                obj_gen(work_file_list[File][1][0][Example],[],0,True,[]),
                obj_gen(work_file_list[File][1][1][Example],[],0,True,[]),
                mc(work_file_list[File][1][0][Example]),
                mc(work_file_list[File][1][1][Example]),
                Print) #The Boolean turns on print outputs for console operation.
    
    pass

def check_matrix(File = 0,Example = 0, inout = 0, cbk = 0):
    """
    Compares two matrices, returning a difference map matrix as well as a 
    list of all rows and columns where changes happen. Tries to match macro 
    objects.

    Parameters
    ----------
    File : Int, optional
        Index of parsed json or txt file in the work_files list. 
        The default is 0.
    Example : Int, optional
        Index of Example in the file. Values usually from 0 to 4. 
        The default is 0.
    inout : Int, optional
        0. The default is 0.
    cbk : Matrix background colour, optional
        Uses this colour as the background colour for calculations. 
        If set negative, will try to figure out the background colour
        itself by calling bkcheck. 
        The default is 0.

    Returns
    -------
    List
        Returns an obj_gen output from Object_finder.

    """
    
    sOb,mOb,obmat = obj_gen((work_file_list[File][1][inout][Example]),[])
    print(sOb," small Objects were found, forming ", len(mOb)," macro objects.")
    if cbk == 0:
        return obj_gen((work_file_list[File][1][inout][Example]),[])
    elif cbk > 0:
        return obj_gen((work_file_list[File][1][inout][Example]),[],cbk)
    else: # if cbk < 0, and a background check is desired.
        bc = mc(work_file_list[File][1][inout])
        mTot, mSiz, mBd = bc[0],bc[4],bc[3]
        cbk =  bkcheck(mSiz, mTot, mBd[0])
        return obj_gen((work_file_list[File][1][inout][Example]),[],0)
        
    sOb,mOb,obmat = obj_gen((work_file_list[File][1][inout][Example]),[])
    print(sOb," small Objects were found, forming ", len(mOb)," macro objects.")
    return obj_gen((work_file_list[File][1][inout][Example]),[])


#Intro Output when running this file from a console:
print("Hello.")
print("This is the main method for the Master Thesis ")
print("'Applying Structural Analogy to Solve Abstract Reasoning Problems in a More Human-like Way'.")
print("To start, enter 'start(folder)', where folder is the location of the example files. ",
      "Or leave it blank to use the default location.")

def commands():
    print("######## Available commands in this program: ########")
    print("- start(folder):\n Use to scan a new folder, or rescan the current one. ",
          "By default, it returns up to five input-output pairs, and only returns ",
          "matrices with no more than nine simple and one complex objects (macro object).")
    print("You can change those settings by adding variables in the parentheses, for Example ",
          "'start(folder,3,8,2)' to accept examples with up to 8 small and 2 macro-objects, ", 
          "and only return the first three examples from each file.\n")
    print("- filelist(A,B):\n To list detected files; A and B are the indices ", 
          "of the files in the list. It will print all files between and including A and B. ",
          "Example: filelist(1,5). \n","Press any key to continue.")
    input()
    print("########################")
    print("The following commands all take input in the form of an index from the generated File ",
          "and some allow choosing an Example from the file by Index.")
    print("All commands will default to File 0, Example 0, if no values are specified, ",
          "meaning the first Example Matrix in the first file.(counts start at 0)\n")
    time.sleep(int(1))
    print("- plot(File):\n Use to create plots of an example file (only in a GUI with plotting capability).",
          " Standard Settings will produce a plot containing up to five input-output pairs, ",
          "as well as generated difference maps in between them.",
          "You can change those settings by adding additional variables:")
    print("- plot(File, Test, Cap, Diff):\n 'Test' can be set to true to plot the test matrix ",
          " of the Example file instead, 'Cap' csets the maximum amount of examples ",
          "you want to see, and 'Diff' can be set to False to not visualize the difference ",
          "between input and output.\n")
    time.sleep(int(1))
    print("- check_matrix(File,Example, IO, BK):\n Use to get details about a specific matrix. ",
          "It will return the Input of the chosen Example.",
          "If you want the output, type 'check_matrix(File,Example,1)' instead. ",
          "The last value can be set to a value of 1 or higher if you want ",
          "to test a matrix with a non-zero background colour. Setting ",
          "BK to a negative value will have the program try to figure out ",
          " the background by itself. \n")
    print("- compare(File,Example):\n Starts a matrix comparison. ",
          "Includes checking both matrices for object data.")
    return
