# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 21:45:35 2021

@author: Jan Martin

Revised Matrix comparator file. 
Checks two arrays for similarities between containing objects.
As this is meant for testing with a console output, it contains a 
lot of print-outs.
"""
import numpy as np

def matrix_dif(inp,outp):
    """
    Tries to find the difference between input and output, IF the same size.
    Will check differences in monochrome and stratified colours if necessary

    Parameters
    ----------
    inp : Array
        The first matrix.
    outp : Array
        The second matrix.

    Returns
    -------
    Tuple
        A Tuple of a Boolean and an Array.

    """
    if np.size(inp) == np.size(outp):
        return (True,(outp - inp))
    else: 
        return (False,())

#Enter two analyzed matrices here
def matrix_comp(mat1, mat2, m1ob, m2ob, m1c = [], m2c = [], pout = False): 
    #mXc contain: [0: totals,1: rows,2: cols,3: bd,4: size]
    
    diff_map = matrix_dif(mat1, mat2)
    diff_col = [[],[]]
    diff_row = [[],[]]
    forswitch = True
    #Rows and Columns of the entire matrices:
    for j in range(len(m1c[1])): # rows
        for key in m1c[1][j] and m2c[1][j]: 
            if key in m1c[1][j] and m2c[1][j] and (
                    m1c[1][j][key] == m2c[1][j][key]):
                continue
            elif forswitch:
                diff_row[0].append((j,mat1[j]))
                diff_row[1].append((j,mat2[j]))
                forswitch = False
                continue
            else:
                forswitch = True
                
    forswitch = True            
    for j in range(len(m1c[2])): # columns
        # print(m1c[2][j])
        # print(m2c[2][j])
        for key in m1c[2][j] and m2c[2][j]: 
            if key in m1c[2][j] and m2c[2][j] and (
                    m1c[2][j][key] == m2c[2][j][key]):
                continue
            elif forswitch:
                diff_col[0].append((j,mat1[:][j]))
                diff_col[1].append((j,mat2[:][j]))
                forswitch = False
                continue
            else:
                forswitch = True
    #Macro Object Comparison
    macrotraits = [[],[]]
    object_relation = []
    for i in range(len(m1ob[1])): #Matrix 1
        mObTraits = [
            m1ob[1][i][1]["dimensions"]["center"],
            m1ob[1][i][1]["dimensions"]["smsize"],
            m1ob[1][i][1]["dimensions"]["median"],
            (m1ob[1][i][1]["cells"] +
            m1ob[1][i][1]["contains"])#.
            #sort(key=lambda tup: tup[0]),
            ]
        macrotraits[0].append(mObTraits)
    for i in range(len(m2ob[1])): #Matrix 2
        nbcell = [k[1] for k in m2ob[1][i][1]["contains"]]
        mObTraits = [
            m2ob[1][i][1]["dimensions"]["center"],
            m2ob[1][i][1]["dimensions"]["smsize"],
            m2ob[1][i][1]["dimensions"]["median"],
            (m2ob[1][i][1]["cells"] +
            nbcell)#.
            #sort(key=lambda tup: tup[0]),
            ]
        macrotraits[1].append(mObTraits)
    
    #Check center, size, median, cells. 2+ equal --> related
    for icount, ival in enumerate(macrotraits[0]):
        for jcount, jval in enumerate(macrotraits[1]):
            if majority(trait_compare(ival,jval),2):
                print(m1ob[1][icount][0])
                object_relation.append(
                    [
                    (m1ob[1][icount][0],m1ob[1][icount][1]["Array"]),
                    (m2ob[1][jcount][0],m2ob[1][jcount][1]["Array"])
                    ]
                        )
    
    
    #Console use printout:
    if pout:

        if diff_map[0] == True:
            print("Difference map of the two matrices: ")
            print(diff_map)
        print("Different rows: ", diff_row)
        #As no new matrix will be shaped off them, there is currently no 
        # need to enumerate them.
        print("different columns: ", diff_col)
        #print("Object Relations: ",object_relation)
        
        for i in object_relation[0][0][1]:
            print(letter_convert(i))
            # Using only the first object pair in the list, 
            # As this is deemed sufficient for a first evaluation
        for i in object_relation[0][1][1]:
            print(letter_convert(i))

    
    return object_relation

# taken from https://stackoverflow.com/a/42514511
def majority(itvar, num):
    """
    Checks if a certain amount of values are True.
    Parameters
    ----------
    itvar : Iterator
        The values to be iterated through.
    num : Int
        DESCRIPTION.

    Returns
    -------
    Bool
        True or False.

    """
    print("checking majority")
    itvar = iter(itvar)
    return all(any(itvar) for _ in range(num))

def trait_compare(tr1,tr2):
    """
    Checks if values from two lists are equal, and returns a list of booleans

    Parameters
    ----------
    tr1 : List
        A list of hopefully comparable values.
    tr2 : List
        A list of hopefully comparable values.

    Returns
    -------
    tlist : List
        A list of Booleans.

    """
    tlist = []
    for i in range(len(tr1)):
        print(tr1[i])
        tlist.append(tr1[i]==tr2[i])
    return tlist

def letter_convert(Li):
    """
    Takes a List of Numbers, and returns a List of Letters

    Parameters
    ----------
    Li : List
        A List of Numbers.

    Returns
    -------
    rLi : List
        A List of Letters.

    """
    rLi = [chr(ord('`')+(x+1)) for x in Li]
    return rLi