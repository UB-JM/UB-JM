# -*- coding: utf-8 -*-
"""
Created on Sat May  8 20:31:51 2021

@author: Jan

Searches an array for non-background values, then generates objects out of 
neighbouring cells, before generating macro-objects from those.
"""

import numpy as np
from itertools import chain as itch
import scipy.ndimage as ndi
cmass = ndi.measurements.center_of_mass
    
def get_tuples(matrix, bk = 0, cellcolour = 0):
    """
    Gets all those juicy tuples, and puts them in a list

    Parameters
    ----------
    matrix : np.array
        Input one of the matrices, containing only numbers, 
        with already determined background.
    bk : Integer, optional
        What is the perceived background colour of the matrix? 
        The default is 0.
    colour : Boolean, optional
        Does colour matter? If not, everything not part of the background 
        will be selected. 
        The default is False.

    Returns
    -------
    LIST
        Lists all non-bk tuples found.

    """
    # if cellcolour == bk:
    #     tup1,tup2 = np.where(matrix != bk)[0],np.where(matrix != bk)[1]
    # else:
    #     tup1,tup2 = np.where(matrix == cellcolour)[0],np.where(matrix == cellcolour)[1]
        
    if cellcolour == bk:
        return list(zip(np.where(matrix != bk)[0],np.where(matrix != bk)[1]))
    else:
        return list(zip(np.where(matrix == cellcolour)[0],np.where(matrix == cellcolour)[1]))

def is_adjac(tup1,tup2, diag = False):
    """
    Checks if two tuples are adjacent, orthogonally or diagonally, and outputs a boolean. 
    Helper function.

    Parameters
    ----------
    tup1 : tuple (a,b)
        A tuple from the list, as found in the original matrix.
    tup2 : tuple (a,b)
        Another tuple from the list, as found in the original matrix..
    diag : Boolean, optional
        If false, check tuples for direct adjacency. The default is False. 
        If true. check tuples for diagonal adjacency.

    Returns
    -------
    bool
        True if adjacent (will be considered part of the same object), false if not.

    """

    if not diag and(tup1[0] == tup2[0]) and (tup1[1]-1 == tup2[1] or tup1[1]+1 == tup2[1]) or (
            tup1[1] == tup2[1]) and (tup1[0]-1 == tup2[0] or tup1[0]+1 == tup2[0]):  
        return True
    if diag and (tup1[1]-1 == tup2[1] or tup2[1] == tup1[1]+1) and (
            tup1[0]-1 == tup2[0] or tup2[0] == tup1[0]+1):
        return True
    return False

#The Main function of this module:
def obj_gen(matrix,objectlist=[], bk = 0, monochrome = True, objectlistmatrix=[], check_macro = True):
    """
    Receives a matrix and a set of variables and returns a list of (small) objects, 
    a list of macro objects consisting of those smaller objects, and a matrix showing
    all found objects ennumerated.

    Parameters
    ----------
    matrix : np.array, 
        As provided by the tester or example. Contains ints from 0 to 9.
    objectlist : List, optional. The default is [].
        A usually empty list, to be filled with objects found in the array. 
        Objects, in this case, are sets of adjacent cells (or just one cell by itself)
        that have a non-background number.
    bk : Integer, optional
        The determined background number, as identified by the matrix bk check. 
        The default is 0.
    monochrome : Boolean, optional. The default is True.
        If True, checks for everything that is not background. 
        Else, it will check colours individually (small objects only).
    objectlistmatrix : np.array, optional. The default is [].
        A matrix generated that shows all identified objects with incrementing numbers.
        This is empty when running the fuction, and merely exists to make it 
        easier to output it into a calling function, if desired.
    check_macro: Boolean, optional. The Default is True.
        If the function should try to find macro objects. 

    Returns
    -------
     objectlist : List (of Ints, Lists, and Dictionaries)
        Lists all objects in the following format:
            [Object ID (Integer), 
             [Individual Cell coordinates (Tuples of two Ints)],
             []]
    macrolist : List
        A list of macro objects in the form of dictionaries. Described in more 
        detail in the "mog" function that generates this list, below.
    objectlistmatrix : array
        A dummy matrix for object listing, to make it easier to work with a relational object.

    """
    
    if monochrome:
        mDim = matrix.shape
        tulist= get_tuples(matrix, bk, bk)
        checkedlist = [] # List of tuples already checked in the followin while loop
        while tulist != []:
            new_temp_obj = [
                #part of object:
                [],
                #adjacent(diagonal) objects:
                [] # <-- these will be the neighbours, used to find macro-objects
                ]
            new_temp_obj[0].append(tulist.pop(0))
            
            for j in new_temp_obj[0]:
                #Checks adjacency to generate small objects
                for i in tulist:
                    if is_adjac(j,i):
                        #if j and i are adjacent, they are part of the same object
                        new_temp_obj[0].append(i)
                        
                        if i in new_temp_obj[1]:
                            #If, for some odd reason, a cell is already in the "neighbour" 
                            # category when being detected as part of the same object, it 
                            # will be removed from the neighbour list.
                            new_temp_obj[1].remove(i)
                        checkedlist.append(i)
                for i in checkedlist:
                    tulist.remove(i) # remove i from the list to not check it again.
                checkedlist.clear()
                for i in tulist:
                    #checks diagonal adjacency
                    if i not in new_temp_obj[0] and is_adjac(j,i,True):
                        new_temp_obj[1].append(i)
        
            if not check_macro and ( # Checking for internal objects in macro objects
                    any(elem[0] == 0 or elem[1] == 0 or 
                       elem[0]+1 == mDim[0] or elem[1]+1 == mDim[1] for elem in new_temp_obj[0])
                    ):
                    new_temp_obj = [[],[]]
                    continue # Border cells can't be "internal".
            
            objectlist.append(new_temp_obj)

    else:
        for k in range(10):
            if k == bk:
                continue
            tulist= get_tuples(matrix, bk, k)
            while tulist != []:
                new_temp_obj = [
                    #part of object:
                    [],
                    #adjacent(diagonal) objects:
                    [] # <-- these will be the neighbours, used to find macro-objects
                    ]
                new_temp_obj[0].append(tulist.pop(0))
                
                for j in new_temp_obj[0]:
                    #Checks adjacency to generate small objects
                    for i in tulist:
                        if is_adjac(j,i):
                            new_temp_obj[0].append(i)
                            tulist.remove(i)
                    for i in tulist:
                        #checks diagonal adjacency
                        if i not in new_temp_obj[0] and is_adjac(j,i,True):
                            new_temp_obj[1].append(i)
                        #Currently, does not check for direct adjacency of different colours
                        
                objectlist.append(new_temp_obj)

    #Create a dummy matrix for object listing (helper function to make it easier 
    # to work with a relational object)
    objectlistmatrix = np.zeros(np.shape(matrix),np.int32)
    
    #Adds a numeric ID to each object, to make the objectlistmatrix at least a 
    # little bit human-readable. The IDs start at 1 because the background is already 0.
     
    for k in range(len(objectlist)):
        objectlist[k].insert(0,k+1)
        if not monochrome or bk != 0:
            #Fills the objectlistmatrix manually if colour matters
            for m in objectlist[k][1]:
                objectlistmatrix[m] = k+1 #Adding actual objects.

    if monochrome and bk == 0:
        #Using scipy's label function in the standard case of background 0, 
        # no colour seperation.
        objectlistmatrix = ndi.label(matrix)[0]
    
    #Uses the objectlistmatrix to convert neighbouring cells into object IDs
    for k in range(len(objectlist)):
        tempvar = objectlist[k][2]
        tempvar[:] = [objectlistmatrix[i[0],i[1]] for i in tempvar] 

    #Adds recursive Neighbour links:
    #As the tuple is removed from the list once it is added to an object, 
    # later objects will not find the previous objects when checking  
    # for neighbours. Thus, they are added here.
    for k in range(len(objectlist)):
        if objectlist[k][2] is not []:
            for y in objectlist[k][2]:
                if y>k and not (k+1) in objectlist[y-1][2]:
                    objectlist[y-1][2].append(k+1)

            
    # Remove useless neighbours (Example: Object 6 has neighbour Object 6)
    for x in objectlist:
        x[2] = list(filter(lambda y: y != x[0], x[2]))
    #Call function to generate Macro-Objects out of adjacent small objects:
        
    macrolist=[]
    if check_macro: # Does not check for macro objects if set to False.
        mog(objectlist, matrix, macrolist, bk)
        print(len(objectlist)," entities were found, forming a total of ",
              len(macrolist)," macro-objects.")
    else:
        for i in range(len(objectlist)):
            #We don't care for diagonal neighbours when checking
            # surrounded objects
             objectlist[i] = objectlist[i][:-1] 
    return objectlist, macrolist, objectlistmatrix



def mog(objectlist,inputmatrix,macro_list=[],bk = 0):
    """
    

    Parameters
    ----------
    objectlist : List
        A list of small objects, generated by checking direct adjacency of 
        non-background (or same colour) cells. Inherited from the calling function, 
        usually obj_gen, and passed along to a sub-function.
    inputmatrix : array
        The matrix in which the objects are found.
    macro_list : TYPE, optional
        DESCRIPTION. The default is [].
    bk : TYPE, optional
        DESCRIPTION. The default is 0.

    Returns
    -------
    macro_list : List
        A list of marco-objects in the form of a dictionary, containing an assigned ID, 
        a list of parts (smaller objects), a sub-dictionary ("coords", see directly below)
        listing the shape and position within the matrix, and  a listing of all cells that 
        are part of the object and not background, as well as the colours present amonst 
        those cells.
        Some of those datapoints will be redundant, that is, can be generated from each other.

    """
    
    #Recursive Neighbour function to gather all adjacent objects:
    checked_objects = []
    for i in range(len(objectlist)):
        parts = []
        
        coords = {
                "top"    :  None, #Highest row that's part of the object
                "bottom" :  None, #Lowest row that's part of the object
                "left"   :  None, #Left-Most column that's part of the object
                "right"  :  None, #Right-Most column that's part of the object
                "com"    :  None, #Center of Mass, weighting all non-bk cells
                "median" :  None, #Cell that is closest to the center
                "smsize" :  None, #Sub-matrix-size: The shape() when creating a matrix from the object
                "center" :  None, #Center of the matrix shape, top left to bottom right
                "top_left": None, #The cell closest to the top left of the matrix
                "dom_col":  None #The dominant colour(s) in the object. 
                #Colours are still individually listed 
                }
        
        if not (i+1) in checked_objects: 
            # ^ This makes sure that objects which are already part of a 
            # macroobject are not checked again.
            #Logs important information about the shape, size, and location of an object
            
            recne(objectlist, i, parts, coords)
            #recne is a helper function to simply get the four sides of an object
            checked_objects.extend(parts)
            
            temp_cells = list(itch.from_iterable([objectlist[x-1][1] for x in parts]))
            # using https://stackoverflow.com/a/953097 as a base
            c_col = cellColCheck(temp_cells,inputmatrix)
            #Checks and lists all the colours that are part of the object. Usually just 1 or 2
            
            coords["com"] = (sum([l[0] for l in temp_cells])/len(temp_cells),
                             sum([l[1] for l in temp_cells])/len(temp_cells))
            coords["center"] = ((coords["top"]+coords["bottom"])/2,(coords["left"]+coords["right"])/2)
            coords["median"] = (round((coords["top"]+coords["bottom"])/2),
                                round((coords["left"]+coords["right"])/2))
            coords["dom_col"] = [i for i, j in enumerate(c_col) if j == max(c_col)]          
            #inspired by https://stackoverflow.com/a/3989032
            coords["top_left"] = min(temp_cells) #getTopLeft(temp_cells,coords["top"],coords["left"])
            #Saved as a list because it is possible that multiple colours make up the 
            # macro object in equal parts
            obSize = ((coords["bottom"]-coords["top"]+1),(coords["right"]-coords["left"]+1))
            #Made a temp object for ease of reusal and readability.
            
            coords["smsize"] = obSize
            
            obArray = object_window(inputmatrix,obSize,(coords["top"],coords["left"]))
            #Searches for contained objects by recalling the function 
            # on the object just generated.
            contains = obj_gen(obArray,[],coords["dom_col"],True,[],False)[0]
            lines,columns = [],[]
            for i in range(coords["smsize"][0]):
                # Lists all rows of the object
                lines.append((obArray[i,:]).tolist())
            for i in range(coords["smsize"][1]):
                # Lists all rows of the object
                columns.append((obArray[:,i]).tolist())         
            
            traits = { #Lists detected features of the object
                "hollow": contains == [],    #Contains encirled cells of non-dominat colour. 
                "axis_sym": np.all(np.transpose(obArray) == obArray),
                    #Object can be mirrored on axis from top-left to bottom-right
                "rot90_sym":  np.all(np.rot90(obArray, 1) == obArray), 
                    #Is object rotationally symmetric?
                "rot180_sym": np.all(np.rot90(obArray, 2) == obArray), 
                    #Can Object be turned by 180 degree?
                "vertical_sym":   np.all(np.flip(obArray, 0) == obArray), 
                     #Is object mirrored across a vertical axis?
                "horizontal_sym": np.all(np.flip(obArray, 1) == obArray),
                     #Is object mirrored across a horizontal axis?
                }
                
            #Creates a new macro object, and lists which small objects it consists of
            new_macro_obj = {
            #Contains objects:
            "Array": obArray, #Array containing just the object, for running functions on
            "parts": parts, #What minor objects this macro-object consists of
            "dimensions": coords,
            "cells": temp_cells,    #Cells that are part of this object
            "colours": [i for i, j in enumerate(c_col) if j != 0],
            "rows": lines,          #Rows in the object
            "columns": columns,     #Columns of the object
            "contains": contains,   #If the object contains minor objects of different colour
            "traits" : traits       #Dict listing traits of the object
            
            # Also "minority colour".
            
            }
            
            macro_list.append([new_macro_obj])
    
    for k in range(len(macro_list)):
    #Adds a numeric ID to each macro object.
    #The IDs start at i+100 to differentiate them from the small objects.
    #It is assumed that no matrix with more than 100 individual objects will
    # be evaluated over the course of this thesis.
        macro_list[k].insert(0,k+100)
        
    return macro_list            

def recne(objectlist, i =0, parts = [], coords={}):
    """
    A recursive helper function to get the four sides of a macro-object.
    Starts with an object, then re-calls itself for its neighbours until 
    there are none left.

    Parameters
    ----------
    objectlist : List
        A list of small objects, generated by checking direct adjacency of 
        non-background (or same colour) cells.
    i : Int, optional
        The position of the object in the object list. The default is 0.
    parts : List, optional
        A list of objects already checked. Prevents a circular macro-object 
        from being infinitely cycled. The default is [].
    coords : Dictionary, optional
        The coordinates dictionary to later be a part of the macro object. 
        The first four entries (top, bottom, left, right) are filled here. 
        Usually starts out empty. The default is {}.

    Returns
    -------
    parts : List
        Parts already checked (see above). Used to prevent infinite 
        recursion in 'recne' and 'mog'
    coords : Dictionary
        On return to mog, this will contain the four object borders.

    """

    parts.append(objectlist[i][0])
    if objectlist[i][2] is not []: # if it's empty, the function is done
        for j in objectlist[i][2]:
            #If 'j' wasn't checked so far, runs the function on that first.
            if not j in parts:
                recne(objectlist, j-1, parts, coords) 
                #The '-1' is due to the count starting at 1, but the 
                # list starting at 0.

    for c in objectlist[i][1]:
        coords["top"] = getCoord(coords.get("top"),c[0],True)
        coords["bottom"] = getCoord(coords.get("bottom"),c[0],False)
        coords["left"] = getCoord(coords.get("left"),c[1],True)
        coords["right"] = getCoord(coords.get("right"),c[1],False)
        
    return parts, coords 

def getCoord(key, tup, comp = True):
    """
    A simple min/max function called by recne.
    Checks an existing number against a new number from a tuple (cell coordinate)
    and keeps the lower/higher value, depending on input.
    Called by a recursive function(recne).

    Parameters
    ----------
    key : Int
        The current highest/lowest value of the coordinate to be checked.
    tup : Int
        One value from a tuple. Whether its the first or second value depends on 
        what is being checked, and is decided on input by the calling function.
    comp : Boolean, optional
        Tells getCoord whether it should check for min or max.
        'True' means minimum, used for "top" and "left" (matrices counting from the top left). 
        'False' means maximum. 
        The default is True.

    Returns
    -------
    key : Int
        Returns the higher/lower of two input values, depending on the comp variable.

    """
    if key is None:
        key = tup
    elif comp:
        key = min(key,tup)
    else:
        key = max(key,tup)
    return key
 
    
def cellColCheck(cList,inputmatrix):
    """
    A simple look-up, taking a list of coordinates and counting the results.

    Parameters
    ----------
    cList : List of tuples
        A list of cell coordinates making up a macro object.
    colourmatrix : np.array
        The original matrix of cells containing numbers.

    Returns
    -------
    found_colours : List
        A list of colours. Each position in the list is a colour corresponding to that position.
        The value of that position is how many times that colour exists in the object.

    """
    found_colours = [0,0,0,0,0,0,0,0,0,0]
    for i in cList:
        found_colours[inputmatrix[i]] += 1
    return found_colours

def object_window(matrix,oSize,oPos):
    """
    A simple Array Slicing operation, outsourced to its own function to 
    facilitate a future refactor

    Parameters
    ----------
    matrix : np.array
        The original Input Matrix.
    oSize : Tuple
        Shape of the object in question.
    oPos : Tuple
        Top Left position of the object.

    Returns
    -------
    np.array window
        View of the matrix at the specific position.

    """
    return matrix[oPos[0]:(oPos[0]+oSize[0]),oPos[1]:(oPos[1]+oSize[1])]
