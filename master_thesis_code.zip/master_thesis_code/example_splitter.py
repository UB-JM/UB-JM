# -*- coding: utf-8 -*-
"""
Folder Walkthrough

@author: Jan Martin

Splits files into input/output, and individual examples
"""

from __future__ import print_function
import numpy as np
import json

#---------------------------------------------------------

def read_file(fl, fpath="training/", cap = 3):
    """
    Reads a file and splits it into train data and test data, then further into input- and output-matrices.

    Parameters
    ----------
    fl : json file
        Contains sets of matrices.
    fpath : String
        The folder where the json files are to be found.    
    cap : Int
        How many examples are to be read from each file. Default is 3.
        
    Returns
    -------
    List
        A list of two sets, one with the training examples, one with the test example.

    """
    flr = fl.read()
    train_data = np.array(json.loads(flr)['train'])
    test_data = np.array(json.loads(flr)['test'])
    ## Generates Empty Lists to be filled with individual examples:
    inputs,outputs = [],[]
    trainr, testr = [inputs,outputs],[]

    for j in range(len(train_data)):
            if j <cap:
                inputs.append(np.array(train_data[j]["input"]))
                outputs.append(np.array(train_data[j]["output"]))
    for i in range(len(test_data)):
        #The test data usually consists of only one pair of matrices, so it does 
        # not need to be split into input and output like the training data
        testr.append(np.array(test_data[i]["input"]))
        testr.append(np.array(test_data[i]["output"]))
    return [trainr,testr]

