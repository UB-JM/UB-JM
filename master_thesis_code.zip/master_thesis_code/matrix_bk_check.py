# -*- coding: utf-8 -*-
"""
Created on Mon Oct 25 01:55:23 2021

@author: Jan Martin

Has two functions:
    mat_count counts all values in a matrix and returns the count for 
    the entire matrix, all rows, all columns, and all border cells 
    (cells bordering the edge of the matrix) seperately.
    
    bkcheck takes those values and decides which colour in the matrix 
    will be assumed to be the "background"-colour against which 
    objects are differentiated.
"""

import numpy as np
from collections import Counter

def mat_count(matrix,do_tot=True,do_rc=True,do_bd=True): # None or True
    """
    Counts values in each row, column, and matrix total, followed by border cell counts if desired.
    Some of those steps are later repeated in other methods, but flexibility and
    readability are valued higher than performance in this case

    Parameters
    ----------
    matrix : np.array
        Input Matrix as an array
    do_tot : BOOL, optional
        Return Totals count of all values or not? The default is True.
    do_rc : BOOL, optional
        Return aggregated count for each row and column? The default is True.
    do_bd : BOOL, optional
        Return count of all border values(nodes at the edge of the matrix)? 
        This is mostly of theoretical value, in case a future relational interpretation 
        of data can't be ruled out.
        The default is True.

    Returns
    -------
    totals: dict
        A sorted dictionary listing how often each value exists in a matrix.
    rows: 
        Like totals, but lists the values rows in a matrix
    cols: 
        Like totals Lists the individual columns in a matrix
    bd: 
        Lists the values of all border cells, that is, cells at the edge of the matrix, 
        like (0,0). 
    np.size(matrix):
        A numpy function returning the size of the array as a single Integer.

    """
    rows,cols = np.array([]),np.array([])
    # counts values in the entire matrix
    totals = {}
    if do_tot:
        totals =  {0 : np.count_nonzero(matrix == 0),
                1 : np.count_nonzero(matrix == 1),
                2 : np.count_nonzero(matrix == 2),
                3 : np.count_nonzero(matrix == 3),
                4 : np.count_nonzero(matrix == 4),
                5 : np.count_nonzero(matrix == 5),
                6 : np.count_nonzero(matrix == 6),
                7 : np.count_nonzero(matrix == 7),
                8 : np.count_nonzero(matrix == 8),
                9 : np.count_nonzero(matrix == 9),
                -1 : np.count_nonzero(matrix == -1)} 
        #Oversimplification due to most matrices being positive value
    bd = [{}] # initialize border count (border and 1 step away from the border)
    for i in range(len(matrix)):  # counts values per row #range(max(matrix.shape[:])
        if do_rc: 
            row = dict()
            np.append(row,{})
            row = {**({0: np.count_nonzero(matrix[i] == 0)} if 
                      np.count_nonzero(matrix[i] == 0) else {}),
                   **({1: np.count_nonzero(matrix[i] == 1)} if 
                      np.count_nonzero(matrix[i] == 1) else {}),
                   **({2: np.count_nonzero(matrix[i] == 2)} if 
                      np.count_nonzero(matrix[i] == 2) else {}),
                   **({3: np.count_nonzero(matrix[i] == 3)} if 
                      np.count_nonzero(matrix[i] == 3) else {}),
                   **({4: np.count_nonzero(matrix[i] == 4)} if 
                      np.count_nonzero(matrix[i] == 4) else {}),
                   **({5: np.count_nonzero(matrix[i] == 5)} if 
                      np.count_nonzero(matrix[i] == 5) else {}),
                   **({6: np.count_nonzero(matrix[i] == 6)} if 
                      np.count_nonzero(matrix[i] == 6) else {}),
                   **({7: np.count_nonzero(matrix[i] == 7)} if 
                      np.count_nonzero(matrix[i] == 7) else {}),
                   **({8: np.count_nonzero(matrix[i] == 8)} if 
                      np.count_nonzero(matrix[i] == 8) else {}),
                   **({9: np.count_nonzero(matrix[i] == 9)} if 
                      np.count_nonzero(matrix[i] == 9) else {}),
                   **({-1: np.count_nonzero(matrix[i] < 0)} if 
                      np.count_nonzero(matrix[i] < 0)>0 else {}),}
            rows = np.append(rows, row)
        # Count borders seperately 


    matt = np.transpose(matrix) # counts values per column (per row in transposed matrix)
    for i in range(len(matt)):
        if do_rc:
            col = {**({0: np.count_nonzero(matt[i] == 0)} if 
                      np.count_nonzero(matt[i] == 0) else {}),
                   **({1: np.count_nonzero(matt[i] == 1)} if 
                      np.count_nonzero(matt[i] == 1) else {}),
                   **({2: np.count_nonzero(matt[i] == 2)} if 
                      np.count_nonzero(matt[i] == 2) else {}),
                   **({3: np.count_nonzero(matt[i] == 3)} if 
                      np.count_nonzero(matt[i] == 3) else {}),
                   **({4: np.count_nonzero(matt[i] == 4)} if 
                      np.count_nonzero(matt[i] == 4) else {}),
                   **({5: np.count_nonzero(matt[i] == 5)} if 
                      np.count_nonzero(matt[i] == 5) else {}),
                   **({6: np.count_nonzero(matt[i] == 6)} if 
                      np.count_nonzero(matt[i] == 6) else {}),
                   **({7: np.count_nonzero(matt[i] == 7)} if 
                      np.count_nonzero(matt[i] == 7) else {}),
                   **({8: np.count_nonzero(matt[i] == 8)} if 
                      np.count_nonzero(matt[i] == 8) else {}),
                   **({9: np.count_nonzero(matt[i] == 9)} if 
                      np.count_nonzero(matt[i] == 9) else {}),
                   **({-1: np.count_nonzero(matt[i] < 0)} if 
                      np.count_nonzero(matt[i] < 0)>0 else {}),}
            cols = np.append(cols, col)
        
    # Count border values
    if do_bd:
        border = dict(Counter(list(matrix[0, :-1]) + list(matrix[:-1, -1]) 
                  + list(matrix[-1, :0:-1]) + list(matrix[::-1, 0]))) 
        bd[0] = border
    else: bd[0] = {}

    return totals, rows, cols, bd, np.size(matrix)

def bkcheck(size,totals,bd):
    """
    Decides which colour is seen as "background".
    The values are admittedly a bit arbitrary, but deciding which colour 
    is the background in a flat image without context is a matter of human opinion.

    Parameters
    ----------
    size : Int 
        The total amount of cells in a matrix, generated from np.size.
    totals : Dict
        Count of all values in a matrix. 
        Example: [1,2,3,3,5] would have {3:2, 1:1, 2:1, 5:1}.
    bd : dict
        A dictionary of the border cells. It is assumed that a value occuring 
        more often at the border of a matrix is more likely to be the "background",
        assuming an otherwise equal count of two values.

    Returns
    -------
    Tuple(Bool, # * Tuple(Value, Count)).
          Returns a Tuple of a Boolean and one or multiple Tuples.
          If True, the function is sure of its choice of background, 
          and returns a single tuple of the chosen value and how often it occurs.
          If False, there is no clear background, and it will return two 
          or three tuples of possible values and how often they occur, 
          in the case of the same count the values are ordered small to big.
          The last output is a failsave and just returns False with one tuple.

    """

    bk_val = [sorted(totals.items(), key=lambda item: item[1],reverse = True)[0]]
    if not    sorted(totals.items(), key=lambda item: item[1],reverse = True)[0][1] >= size *3/4:
        bk_val.append(  sorted(totals.items(), key=lambda item: item[1],reverse = True)[1]  )
        #If the most numerous value is not at least 75% of the matrix, 
        # add the second most numerous one to the list
    if not (sorted(totals.items(), key=lambda item: item[1],reverse = True)[0][1] + 
            sorted(totals.items(), key=lambda item: item[1],reverse = True)[1][1]) >= size *3/4:
        bk_val.append(  sorted(totals.items(), key=lambda item: item[1],reverse = True)[2]  )
        #If that's still not enough, add a third. This is as far as it goes.
    if (bk_val[0][1] >= 0.67 * size or
        (bk_val[0][1] >= 0.4 * size and bk_val[0][1] >= (
         sorted(bd.items(), key=lambda item: item[1],reverse = True)[0][1])/2)):
        #One colour makes up at least 67% of the matrix, 
        # or >40% and the majority of the outer edges of the matrix
        return (True, bk_val[0])
    elif ((bk_val[1][1] >= 0.4 * size and bk_val[1][1] >= (
         sorted(bd.items(), key=lambda item: item[1],reverse = True)[0][1])/2)):
        return (True, bk_val[1])
        #It may pick the second most colour if that has the border majority.
    elif len(bk_val) > 1 and bk_val[0][1] >= 2* bk_val[1][1]:
        return (False, bk_val[0], bk_val[1]) 
    elif len(bk_val) > 2:
        return (False, bk_val[0],bk_val[1],bk_val[2])
    else: 
        return(False, bk_val[0])