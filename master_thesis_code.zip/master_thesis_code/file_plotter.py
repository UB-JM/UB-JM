# -*- coding: utf-8 -*-
"""
Created(refactor) on Thu Oct 28 17:39:53 2021

@author: Jan Martin
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as mcm

NUM_COLORS = 6
# from matplotlib.colors import ListedColormap, LinearSegmentedColormap
pk = mcm.get_cmap('inferno', 10)

#cm1 = pylab.get_cmap('gist_rainbow')
for i in range(NUM_COLORS):
    color = pk(1.*i/NUM_COLORS)  # color will now be an RGBA tuple

#Creates a visual representation of matrices with matplotlib.
def plot_ex(train_in,train_out = [], is_test = False, cap = 5, detail = 3):
    """
    Here it plots the matrices to allow visualization for a human tester/supervisor.

    Parameters
    ----------
    train_in : List of arrays
        The Input matrices of the training data.
    train_out : List of arrays, optional
        The Output matrices of the training data. If no output is given, it just plots the input.
    is_test: Bool
        If this is a testing matrix, the matrices are one layer higher in the list cascade.
        The default is False. If set to true, the following input variables will be treated 
        as if set to 1.
   cap: Int
       Shows how many rows should be plotted at max. The default is 5, which 
       corresponds to the default of five input-output pairs being pulled from
       an example json file in Folder_walk.py. 
   detail : Int, optional
        If the difference (output - input) should also be plotted. 
        3: Yes, input, output, difference
        2: No, just Input and output.
        1: No, only plots a single matix.        
        The default is 3. Values over 3 make no sense.

    Returns
    -------
    None. As the output is shown in the IDE's plot tab, there is no internal output. 

    """
    fig = plt.figure()
    ex_count = min(len(train_in),cap)
    if is_test or train_out == []:
        #Test matrices will always be plotted alone, as if detail was == 1
        fig.add_subplot(1,1,1).imshow(train_in[0],interpolation = 'nearest', 
                                      cmap=pk, vmin=-1.0, vmax=8.0)
        if is_test and not train_out == []:
            plt.show() 
            fig = plt.figure()  #Special case: Clearing variable for a double output
            fig.add_subplot(1,1,1).imshow(train_in[1],interpolation = 'nearest', 
                                          cmap=pk, vmin=-1.0, vmax=8.0)

    elif detail >=3:
        for j in range(ex_count):  
            fig.add_subplot(ex_count,3,(1+j)*3-2).imshow(
                train_in[j], interpolation = 'nearest', cmap=pk, vmin=-1.0, vmax=8.0)
            fig.add_subplot(ex_count,3,(1+j)*3-1).imshow(
                np.array(train_out[j])-np.array(train_in[j]), interpolation = 'nearest', 
                cmap=pk, vmin=-1.0, vmax=8.0)
            fig.add_subplot(ex_count,3,(1+j)*3).imshow(
                train_out[j], interpolation = 'nearest', cmap=pk, vmin=-1.0, vmax=8.0)
    elif detail == 2:
        for j in range(ex_count):  
            fig.add_subplot(len(train_in),2,(1+j)*2-1).imshow(
                train_in[j], interpolation = 'nearest', cmap=pk, vmin=-1.0, vmax=8.0)
            fig.add_subplot(len(train_out),2,(1+j)*2).imshow(
                train_out[j], interpolation = 'nearest', cmap=pk, vmin=-1.0, vmax=8.0)
            fig.add_subplot()
    else:
        for j in range(ex_count):  
            plt.figure().add_subplot(len(train_in),1,(1+j)*2-1).imshow(
                train_in[j], interpolation = 'nearest', cmap=pk, vmin=-1.0, vmax=8.0)
    
    plt.show()