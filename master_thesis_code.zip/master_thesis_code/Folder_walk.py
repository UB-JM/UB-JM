# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 16:58:26 2021

@author: Jan Martin

This method contains two functions, find_examples and list_files, 
responsible for reading and listing all files with a specific ending 
in a folder, and outputting part of that list on request, respectinvely. 
Is called by main. 
"""

from os import listdir
from os.path import isfile, join
import scipy.ndimage as ndi

import example_splitter as xsplit
from matrix_bk_check import bkcheck as bkcheck
from matrix_bk_check import mat_count as mc
from matrix_comparator import matrix_dif as mdiff

def find_examples(folder_path = "training/", ex_cap = 5, 
                  objectlimit = 9, macrolimit = 1):
    """
    Scans the given folder, finding all files, calls other modules to read 
    and filter them.
    Afterwards, the content of the files is put into a list.

    Parameters
    ----------
    folder_path : String, optional
        The path where the example files are to be found. 
        The default is "training/".
    ex_cap : Int, optional
        How many examples should be pulled. It's usually less than 5. 
        The default is 5.
    objectlimit : Int, optional
        Ignores Matrices with more than that many detected objects. 
        Meant to limit the testing domain to smaller problems that can be 
        checked in reasonable time. 
        The default is 9.
    macrolimit : Int, optional
        How many Macro Objects are acceptable in the input matrix. 
        Just like objectlimit, this is meant to limit the problem size for 
        a first evaluation; If there are problems with few objects, 
        more will not solve them. 
        The default is 1.

    Returns
    -------
    work_files : List
        A list of all the work files.

    """
    # folder_path = "training/"
    ex_files = [join(folder_path, a) for a in listdir(folder_path) if 
                isfile(join(folder_path, a)) 
                and (a.endswith(".json") or a.endswith(".txt"))]
    work_files = []
    for f in ex_files:
        
        traindata,testdata = xsplit.read_file(open(f),folder_path, ex_cap)
        if mdiff(traindata[0][0],traindata[1][0])[0]:
            m_totals, rows, cols, bd, size = mc(traindata[0][0])

            if bkcheck(size,m_totals,bd[0])[0]:
                if (ndi.label(traindata[0][0])[1] <= objectlimit and 
                    ndi.label(traindata[0][0],[[1,1,1],[1,1,1],[1,1,1]])[1] 
                    <= macrolimit and
                    ndi.label(traindata[0][0],[[1,1,1],[1,1,1],[1,1,1]])[1] 
                    <= macrolimit+1 ):
                    #Generating work entity:
                    work_entity = [traindata[0],traindata[1],testdata]
                    work_files.append([f,work_entity])

            
    print(len(work_files)," files are fulfilling the set criteria")
        
    return work_files

def list_files(file_list,fa,fb):
    """
    Allows returning part of the work files list in a print-friendly package.
    Just enter the name of the list, and from where to where you want it read.

    Parameters
    ----------
    file_list : List
        A list of example files, with their file name saved at [i][1].
    fa : Int
        From where to start returning the file names.
    fb : Int
        Until where to read out the list, including the value given.

    Returns
    -------
    list_output : List
        Returns a List of Tuples, with the index number and the file name.

    """
    list_output = []
    if fa > fb: # Just a failsave
        fa,fb = fb,fa
    for i in range(fa,min(fb+1,len(file_list))): 
        #returns files from index A to B, capped at list length
        list_output.append((i,file_list[i][0]))
    return list_output

